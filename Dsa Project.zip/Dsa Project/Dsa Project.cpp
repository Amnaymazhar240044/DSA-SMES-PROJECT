#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <chrono>
#include <iomanip>
#include <string>

using namespace std;

struct Voter {
    string id;
    string fname;
    string lname;
    int age;
    bool voted;
    string votedForCandidate;
    long long voteTime;  // seconds since epoch or 0
};

vector<Voter> voters;
map<string, int> votes;
vector<string> candidateNames = { "PTI", "PMLN", "PPP", "TLP", "PMLQ", "Independent" };

const string VOTER_FILE = "voters.txt";
const string VOTES_FILE = "votes.txt";

// QuickSort helpers
void swapVoters(Voter& a, Voter& b) {
    Voter temp = a;
    a = b;
    b = temp;
}

int partition(int low, int high) {
    string pivot = voters[high].id;
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (voters[j].id < pivot) {
            i++;
            swapVoters(voters[i], voters[j]);
        }
    }
    swapVoters(voters[i + 1], voters[high]);
    return i + 1;
}

void quickSort(int low, int high) {
    if (low < high) {
        int pi = partition(low, high);
        quickSort(low, pi - 1);
        quickSort(pi + 1, high);
    }
}

void pause() {
    cout << "\nPress Enter to continue...";
    cin.ignore();
}

string trim(const string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

void loadVoters() {
    voters.clear();
    ifstream fin(VOTER_FILE);
    if (!fin) {
        cout << "Warning: " << VOTER_FILE << " not found. Starting with empty voter list.\n";
        return;
    }

    string line;
    while (getline(fin, line)) {
        if (line.empty()) continue;
        istringstream iss(line);
        Voter v;
        int votedInt;
        string votedForCandidate;

        iss >> v.id >> v.fname >> v.lname >> v.age >> votedInt;
        v.voted = (votedInt != 0);

        // Handle potential remaining data on the line for votedForCandidate and voteTime
        // This is a more robust way to read optional fields
        string remaining;
        getline(iss, remaining); // Read the rest of the line
        istringstream issRemaining(remaining);

        // Skip leading whitespace in remaining
        string tempCandidate;
        if (issRemaining >> tempCandidate) {
            if (tempCandidate == "0" || tempCandidate == "\"\"") {
                v.votedForCandidate = "";
            }
            else {
                v.votedForCandidate = tempCandidate;
            }
        }
        else {
            v.votedForCandidate = "";
        }

        long long voteTimeInt = 0;
        if (issRemaining >> voteTimeInt) {
            v.voteTime = voteTimeInt;
        }
        else {
            v.voteTime = 0;
        }

        voters.push_back(v);
    }
    fin.close();

    if ((int)voters.size() > 1) {
        quickSort(0, (int)voters.size() - 1);
    }
}

void saveVoters() {
    ofstream fout(VOTER_FILE);
    for (auto& v : voters) {
        fout << v.id << ' ' << v.fname << ' ' << v.lname << ' ' << v.age << ' '
            << (v.voted ? 1 : 0) << ' ' << (v.votedForCandidate.empty() ? "0" : v.votedForCandidate) << ' ' << v.voteTime << '\n';
    }
}

void loadVotes() {
    votes.clear();
    for (auto& c : candidateNames) votes[c] = 0;
    ifstream fin(VOTES_FILE);
    if (!fin) return;
    string name; int count;
    while (fin >> name >> count) votes[name] = count;
    fin.close();
}

void saveVotes() {
    ofstream fout(VOTES_FILE);
    for (auto& pair : votes) fout << pair.first << ' ' << pair.second << '\n';
}

// Original getVoterById - remains for registration check
Voter* getVoterById(const string& id) {
    for (auto& v : voters)
        if (v.id == id)
            return &v;
    return nullptr;
}

// New function to search by ID, FName, and LName
Voter* findVoter(const string& id, const string& fname, const string& lname) {
    for (auto& v : voters) {
        if (v.id == id && v.fname == fname && v.lname == lname) {
            return &v;
        }
    }
    return nullptr;
}


int getIntInput() {
    while (true) {
        string input;
        getline(cin, input);
        try {
            int val = stoi(input);
            return val;
        }
        catch (...) {
            cout << "Invalid input! Please enter a number: ";
        }
    }
}

void registerVoter() {
    string id, fname, lname;
    int age;
    cout << "Enter Student ID: "; getline(cin, id);
    if (getVoterById(id)) { // Still use getVoterById for quick ID check
        cout << "Already registered with this ID.\n";
        pause(); return;
    }
    cout << "Enter First Name: "; getline(cin, fname);
    cout << "Enter Last Name: "; getline(cin, lname);
    cout << "Enter Age: ";
    age = getIntInput();
    if (age < 18) {
        cout << "Age must be 18 or older.\n";
        pause(); return;
    }
    voters.push_back({ id, fname, lname, age, false, "", 0 });
    quickSort(0, (int)voters.size() - 1);
    saveVoters();
    cout << "Registration successful!\n";
    pause();
}

Voter* loginVoter() {
    string id, fname, lname;
    cout << "Enter Student ID: "; getline(cin, id);
    cout << "Enter First Name: "; getline(cin, fname);
    cout << "Enter Last Name: "; getline(cin, lname);

    // Use the new findVoter function for login
    Voter* v = findVoter(id, fname, lname);
    if (!v) {
        cout << "Login failed. Student ID, First Name, or Last Name is incorrect or not registered.\n";
        pause();
        return nullptr;
    }
    return v;
}

void listCandidates() {
    cout << "\n--- Candidates ---\n";
    for (int i = 0; i < (int)candidateNames.size(); ++i) {
        cout << (i + 1) << ". " << candidateNames[i] << '\n';
    }
}

void vote(Voter& v) {
    if (v.voted) {
        cout << "You have already voted.\n";
        pause(); return;
    }
    listCandidates();
    cout << "\nYou have 15 seconds to vote.\nEnter candidate number: ";

    auto start = chrono::steady_clock::now();
    string input;
    getline(cin, input);
    auto end = chrono::steady_clock::now();

    if (chrono::duration_cast<chrono::seconds>(end - start).count() > 15) {
        cout << "\nToo late! Vote cancelled.\n";
        pause(); return;
    }

    int choice;
    try {
        choice = stoi(input);
    }
    catch (...) {
        cout << "Invalid input!\n";
        pause(); return;
    }

    if (choice < 1 || choice >(int)candidateNames.size()) {
        cout << "Invalid choice.\n";
        pause(); return;
    }

    string candidate = candidateNames[choice - 1];
    votes[candidate]++;
    v.voted = true;
    v.votedForCandidate = candidate;
    v.voteTime = chrono::duration_cast<chrono::seconds>(
        chrono::steady_clock::now().time_since_epoch())
        .count();

    saveVotes();
    saveVoters();
    cout << "Vote recorded. Thank you!\n";
    pause();
}

void cancelVote(Voter& v) {
    if (!v.voted) {
        cout << "You have not voted yet.\n";
        pause(); return;
    }

    long long now = chrono::duration_cast<chrono::seconds>(
        chrono::steady_clock::now().time_since_epoch())
        .count();

    long long duration = now - v.voteTime;

    if (duration > 60) {
        cout << "Sorry, the 1-minute window to cancel your vote has expired.\n";
        pause(); return;
    }

    votes[v.votedForCandidate]--;
    v.voted = false;
    v.votedForCandidate = "";
    v.voteTime = 0;

    saveVotes();
    saveVoters();
    cout << "Your vote has been cancelled.\n";
    pause();
}

void showVoters() {
    cout << left << setw(10) << "ID" << setw(15) << "First Name" << setw(15) << "Last Name"
        << setw(6) << "Age" << setw(8) << "Voted" << "Voted For\n";

    for (auto& v : voters) {
        cout << left << setw(10) << v.id
            << setw(15) << v.fname
            << setw(15) << v.lname
            << setw(6) << v.age
            << setw(8) << (v.voted ? "Yes" : "No")
            << (v.votedForCandidate.empty() ? "None" : v.votedForCandidate)
            << '\n';
    }
    pause();
}

void showResults() {
    cout << "\n--- Results ---\n";
    string winner = "";
    int maxVotes = -1;
    for (auto& c : candidateNames) {
        cout << c << ": " << votes[c] << '\n';
        if (votes[c] > maxVotes) {
            maxVotes = votes[c];
            winner = c;
        }
    }
    cout << "\nWinner: " << (maxVotes <= 0 ? "No votes yet" : winner) << '\n';
    pause();
}

bool adminLogin() {
    string username, password;
    cout << "Enter admin username: ";
    cin >> username;
    cout << "Enter admin password: ";
    cin >> password;
    cin.ignore(); // clear newline
    return (username == "admin" && password == "admin123");
}

void adminMenu() {
    int ch;
    while (true) {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
        cout << "\n==== Admin Panel ====\n";
        cout << "1. Show Voters\n2. Show Candidates\n3. Show Results\n0. Logout\nChoice: ";
        ch = getIntInput();
        switch (ch) {
        case 1: showVoters(); break;
        case 2: listCandidates(); pause(); break;
        case 3: showResults(); break;
        case 0: return;
        default: cout << "Invalid choice.\n"; pause();
        }
    }
}

void menu() {
    int ch;
    while (true) {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
        cout << "\n==== Voting App ====\n";
        cout << "1. Register Voter\n2. Login & Vote\n3. Cancel Vote (within 1 min)\n4. Admin Login\n0. Exit\nChoice: ";
        ch = getIntInput();
        switch (ch) {
        case 1: registerVoter(); break;
        case 2: {
            Voter* v = loginVoter(); // Now asks for ID, FName, LName
            if (v) vote(*v);
            break;
        }
        case 3: {
            Voter* v = loginVoter(); // Now asks for ID, FName, LName
            if (v) cancelVote(*v);
            break;
        }
        case 4: {
            if (adminLogin()) {
                cout << "\nAdmin login successful.\n";
                pause();
                adminMenu();
            }
            else {
                cout << "\nInvalid admin credentials.\n";
                pause();
            }
            break;
        }
        case 0:
            cout << "Exiting...\n";
            return;
        default:
            cout << "Invalid choice.\n";
            pause();
        }
    }
}

int main() {
    loadVoters();
    loadVotes();
    menu();
    return 0;
}